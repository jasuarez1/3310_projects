﻿using System;

namespace Report2
{
    class Program
    {
        static void Main(string[] args)
        {
            List list = new List();
            Console.WriteLine("Cool");

            bool aBoolean = true;
            char aCharacter = '$';
            int anInteger = 34567;
            string aString = "hello";

            list.InsertAtFront(0);
            list.Display();
            list.InsertAtFront(1);
            list.Display();
            list.InsertAtFront(2);
            list.Display();
            list.InsertAtFront(3);
            list.Display();
            list.InsertAtFront(4);
            list.Display();
            list.InsertAtFront(5);
            list.Display();
            list.InsertAtFront(6);
            list.Display();
            list.InsertInTheMiddle("hel1o", 3);
            list.Display();
            list.InsertInTheMiddle(aCharacter, 0);
            list.Display();
            list.InsertInTheMiddle(aBoolean, 8);
            list.Display();
            list.RemoveInTheMiddle(4);
            list.Display();
            list.RemoveInTheMiddle(0);
            list.Display();
            list.RemoveInTheMiddle(6);
            list.Display();
            int ch = 0;
            string choice;
            int place = 0;
            while (true)
            {
                Console.WriteLine("1 to insert, 2 to remove");
                ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                {
                    Console.WriteLine("Enter what you want");
                    choice = Console.ReadLine();
                    Console.WriteLine("Enter placement");
                    place = int.Parse(Console.ReadLine());
                    list.InsertInTheMiddle(choice, place);
                    list.Display();
                }
                else if (ch == 2)
                {
                    Console.WriteLine("Enter placement");
                    place = int.Parse(Console.ReadLine());
                    list.RemoveInTheMiddle(place);
                    list.Display();
                }
            }

            /*object removedObject;

            try
            {
                removedObject = list.RemoveFromFront();
                Console.WriteLine(removedObject + " removed");
                list.Display();
                Console.WriteLine(list.Count());

                removedObject = list.RemoveFromFront();
                Console.WriteLine(removedObject + " removed");
                list.Display();
                Console.WriteLine(list.Count());

                removedObject = list.RemoveFromBack();
                Console.WriteLine(removedObject + " removed");
                list.Display();
                Console.WriteLine(list.Count());

                removedObject = list.RemoveFromBack();
                Console.WriteLine(removedObject + " removed");
                list.Display();
                Console.WriteLine(list.Count());
            }
            catch (EmptyListException emptyListException)
            {
                Console.Error.WriteLine("\n" + emptyListException);
            }*/
        }
    }
}
