package report_1;
import java.util.Scanner;

public class MyClass 
{
	public static void main(String[] args) 
	{
		Scanner dt=new Scanner(System.in);
		
		System.out.print("Enter Factorial: ");
		
		int fact=(dt.nextInt());
		
		int num=1;
		for(int x=1; x<=fact;x++) 
		{
			num=num*x;
			System.out.println("Int: "+x+"!= "+num);
		}
		
		System.out.println("");
		
		
		long num2=1;
		for(int x=1; x<=fact;x++) 
		{
			num2=num2*x;
			System.out.println("Long: "+x+"!= "+num2);
		}
		
		System.out.println("");
		
		
		float num3=1;
		for(int x=1; x<=fact;x++) 
		{
			num3=num3*x;
			System.out.println("Float: "+x+"!= "+num3);
		}
		
		System.out.println("");
		
		
		double num4=1;
		for(int x=1; x<=fact;x++) 
		{
			num4=num4*x;
			System.out.println("Double: "+x+"!= "+num4);
		}
		
		
	}
}
