format long; format compact; clc; 

f40 = factorial(40)
f41 = factorial(41)
f42 = factorial(42)
f43 = factorial(43)
f44 = factorial(44)
f45 = factorial(45)
f46 = factorial(46)
f47 = factorial(47)
f48 = factorial(48)
f49 = factorial(49)
f50 = factorial(50)
